# netcheckup

**netcheckup** is a lightweight internet health diagnostic tool. It can check DNS resolution time, ping latency, and common port connectivity.

## Usage

```bash
netcheckup
```